<?php
/** 
* WEB SERVICE RESPONSE
* @author Abdul R. Wahid
* @copyright Copyright (c) 2015, PT Gamatechno Indonesia
* @license http://gtfw.gamatechno.com/#license
**/

require_once Configuration::Instance()->GetValue( 'application', 'docroot') . 'module/manako_app/business/'.Configuration::Instance()->GetValue( 'application','db_conn',0,'db_type').'/App.class.php';

class ViewDataApp extends JsonResponse {

   function TemplateModule() {
   }
   
   function ProcessRequest() {
      $msg = Messenger::Instance()->Receive(__FILE__); //Kayaknya nanti tetep diperlukan

		$dataRequest = $_REQUEST['data'];
      $dataStart = $_REQUEST['start'];
      $dataDisplay = $_REQUEST['length'];
      $DTdraw = $_REQUEST['draw'];
      if (isset($_REQUEST['search'])) {
         $DTUniFind = $_REQUEST['search']['value'];
      } else {
         $DTUniFind = '';
      } // used to prevent error when use clientside processing

      if (isset($_REQUEST['filter'])) {
         $filter = $_REQUEST['filter'];
         foreach ($filter as $key => $value) {
            $filter[$key] = $value;
         }
      } else {
         $filter = '';
      } // used to prevent error when use clientside processing
      
      /*Cook Filter*/
      // $filter           = Array();
      // $filter           = $_POST->AsArray();
      // if (empty($filter)) {
      //    $filter['model'] = '';
      // }
      // if (!empty($filter['model'])) {
      //    $filter['expand']    = 'true';
      //    $filter['collapse']  = 'in';
      // } else {
      //    $filter['expand']    = 'false';
      //    $filter['expand']    = '';
      // }      
      // $return['filter'] = $filter;

      /*Cook list*/
      if ($dataDisplay == '-1') {
         $dataDisplay = '';
      }
      $appObj  = new App();
      $dataAppAll = $appObj->GetDataApp('',null,null);
      $dataAppTotal = $appObj->GetTotalData();
      $dataApp = $appObj->GetDataApp($DTUniFind,$dataStart,$dataDisplay);
      $dataAppFiltered = $appObj->GetTotalData();
      if (!empty($dataApp)) {
         $dataApp = $dataApp;
         $len        = sizeof($dataApp);
         for ($i=0; $i<$len; $i++) {
            
            $listApp[$i]       = $dataApp[$i];

            /*Datatables*/
            // $DTApp[$i]['productName']      = $dataApp[$i]['productName'];
            // $DTApp[$i]['varianName']       = $dataApp[$i]['varianName'];
            // $DTApp[$i]['appName']          = $dataApp[$i]['appName'];
            // $DTApp[$i]['appDirInstall']    = $dataApp[$i]['appDirInstall'];
            // $DTApp[$i]['appPathDev']       = $dataApp[$i]['appPathDev'];
            // $DTApp[$i]['appPathDocRepo']   = $dataApp[$i]['appPathDocRepo'];
            // $DTApp[$i]['appPathDocFile']   = $dataApp[$i]['appPathDocFile'];
            
            // $listApp[$i]['no'] = $i+1;

            $idEnc      = Dispatcher::Instance()->Encrypt($listApp[$i]['appId']);
            $listApp[$i]['url']['url_edit']    = Dispatcher::Instance()->GetUrl('manako_app', 'inputApp', 'view', 'html') . '&idd=' . $idEnc;
                        
            $urlAccept = 'manako_app|deleteApp|do|';
            $urlReturn = 'manako_app|app|view|';
            $label      = 'App';
            $dataName   = $listApp[$i]['appName'];
            $listApp[$i]['url']['url_delete']  = Dispatcher::Instance()->GetUrl('confirm', 'confirmDelete', 'do', 'html').'&urlDelete='. $urlAccept.'&urlReturn='.$urlReturn.'&id='.$idEnc.'&label='.$label.'&dataName='.$dataName;
         }         
         // $return['list'] = $listApp;
      } else {
         $listApp = array();
      }
      // $return['total'] = $dataAppTotal[0]['totalData'];  

      if ($dataRequest == 'list') {
         $return['list'] = $listApp;
         echo json_encode($return['list']);
      } elseif ($dataRequest == 'datatables') {
         $return['draw'] = $DTdraw;
         $return['recordsTotal'] = $dataAppTotal[0]['totalData'];
         $return['recordsFiltered'] = $dataAppFiltered[0]['totalData'];
         $return['data'] = $listApp;
         echo json_encode($return);
      } elseif ($dataRequest == 'filter') {
         $return['filter'] = $filter;
         echo json_encode($return['filter']);
      } elseif ($dataRequest == 'total') {
         $return['total'] = $dataAppTotal[0]['totalData'];
         echo json_encode($return['total']);
      } else {
         $return['list'] = $listApp;
         $return['filter'] = $filter;
         $return['total'] = $dataAppTotal[0]['totalData'];
         $return['msg'] = $msg;
         echo json_encode($return);
      }  
      exit();      
   }

   function ParseTemplate($data = NULL) {
   }
}
?>
