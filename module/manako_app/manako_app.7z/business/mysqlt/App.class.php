<?php
/** 
* @author Abdul R. Wahid
* @copyright Copyright (c) 2015, PT Gamatechno Indonesia
* @license http://gtfw.gamatechno.com/#license
**/

class App extends Database {

   protected $mSqlFile= 'module/manako_app/business/mysqlt/app.sql.php';
   
   function __construct($connectionNumber=0) {
      parent::__construct($connectionNumber);
      //$this->setDebugOn();
   }
   
//===READ===  
   function GetDataApp($uniFind, $start, $display) {
      $limit = '';
      $finds = '';
      if ($start != '' && $display != ''){
         $limit = "LIMIT $start, $display";
      }
      if ($uniFind != '') {
         $finds = "WHERE appName LIKE '%$uniFind%' OR productName LIKE '%$uniFind%' OR varianName LIKE '%$uniFind%' OR appDirInstall LIKE '%$uniFind%' OR appPathDev LIKE '%$uniFind%' OR appPathDocRepo LIKE '%$uniFind%' OR appPathDocFile LIKE '%$uniFind%'";
      }
      
      $query  = $this->mSqlQueries['get_data_app'];
      $query  = str_replace('-- limit --', $limit, $query);
      $query  = str_replace('-- finds --', $finds, $query);
      $result = $this->Open($query, array());
      return $result;
   }
   function GetDataAppById($id) {
      $result = $this->Open($this->mSqlQueries['get_data_app_by_id'], array($id));
      return $result;
   }
   function GetTotalData() {
      $result = $this->Open($this->mSqlQueries['get_total_data'], array());
      return $result;
   }   
//===CREATE===
   function DoAddApp($model) {
      $result = $this->Execute($this->mSqlQueries['do_add_app'], array($model));
      return $result;
   }
   function GetCountDuplicateModelAdd($model) {
      $result  = $this->Open($this->mSqlQueries['get_count_duplicate_model_add'], array($model));
      return $result;
   }
//===UPDATE===
   function DoUpdateApp($model, $UpdateTime, $UpdateUser, $id) {
      $result = $this->Execute($this->mSqlQueries['do_update_app'], array($model, $UpdateTime, $UpdateUser, $id));
      return $result;
   }
   function GetCountDuplicateModel($model, $id) {
      $result  = $this->Open($this->mSqlQueries['get_count_duplicate_model'], array($model, $id));
      return $result;
   }
//===DELETE===
   function DoDeleteApp($id) {
      $result = $this->Execute($this->mSqlQueries['do_delete_app'], array($id));
      return $result;
   }
}