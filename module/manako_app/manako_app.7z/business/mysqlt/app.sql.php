<?php
/*---View---*/
$sql['get_data_app'] = 
   "SELECT SQL_CALC_FOUND_ROWS
     appId,
     appProductId,
     productName,
     appVarianId,
     varianName,
     appName,
     appDirInstall,
     appPathDev,
     appPathDocRepo,
     appPathDocFile
   FROM 
      project_app
   LEFT JOIN project_app_product
   ON appProductId = productId
   LEFT JOIN project_app_varian
   ON appVarianId = varianId
   -- finds --
   ORDER BY 
     appName
   -- limit --
   ";

$sql['get_data_app_by_id'] = 
   "SELECT
     appId,
     appProductId,
     productName,
     appVarianId,
     varianName,
     appName,
     appDirInstall,
     appPathDev,
     appPathDocRepo,
     appPathDocFile
   FROM 
      project_app
   LEFT JOIN project_app_product
   ON appProductId = productId
   LEFT JOIN project_app_varian
   ON appVarianId = varianId
   WHERE
     appId = '%s'
   ORDER BY 
     appName
   ";

$sql['get_total_data'] =
   "SELECT FOUND_ROWS() AS totalData
   ";

/*---DoAdd---*/
$sql['do_add_app'] =
   "
   ";

$sql['get_count_duplicate_model_add'] =
   "
   ";

/*---DoUpdate---*/
$sql['do_update_app'] =
   "
   ";

$sql['get_count_duplicate_model'] =
   "
   ";

/*---DoDelete---*/
$sql['do_delete_app'] =
   "
   ";

?>

